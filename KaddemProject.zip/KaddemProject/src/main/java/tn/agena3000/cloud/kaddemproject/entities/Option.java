package tn.agena3000.cloud.kaddemproject.entities;
public enum Option {
    GAMIX,
    SE,
    SIM,
    NIDS;
}