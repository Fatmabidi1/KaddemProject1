package tn.agena3000.cloud.kaddemproject.entities;

public enum Specialite {
    IA,
    RESEAUX,
    CLOUD,
    SECURITE;
}