package tn.agena3000.cloud.kaddemproject.entities;


public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT;

}