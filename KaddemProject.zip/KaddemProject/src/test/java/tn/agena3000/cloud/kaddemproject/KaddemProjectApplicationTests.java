package tn.agena3000.cloud.kaddemproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaddemProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
